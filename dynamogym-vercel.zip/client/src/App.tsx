import DynamoGym from "./DynamoGym";

function App() {
  return <DynamoGym />;
}

export default App;
